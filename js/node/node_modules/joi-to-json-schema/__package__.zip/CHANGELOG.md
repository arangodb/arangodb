## [**2.0.0**](https://github.com/lightsofapollo/joi-to-json-schema/commit/620f7f15d6cc28e1e647b2ec9a8355be69af423c)
- [**#2**](https://github.com/lightsofapollo/joi-to-json-schema/issues/2) Added support for joi.forbidden() in object properties
