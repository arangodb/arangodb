require('6to5/register');
