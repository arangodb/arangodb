var convert = require('./convert'),
    func = convert('words', require('../words'));

func.placeholder = require('./placeholder');
module.exports = func;
