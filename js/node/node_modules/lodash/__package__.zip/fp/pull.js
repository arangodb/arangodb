var convert = require('./convert'),
    func = convert('pull', require('../pull'));

func.placeholder = require('./placeholder');
module.exports = func;
