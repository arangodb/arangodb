var convert = require('./convert'),
    func = convert('sortedLastIndex', require('../sortedLastIndex'));

func.placeholder = require('./placeholder');
module.exports = func;
