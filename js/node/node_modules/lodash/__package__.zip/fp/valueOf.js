var convert = require('./convert'),
    func = convert('valueOf', require('../valueOf'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
