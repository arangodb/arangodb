module.exports = [require("./Longyearbyen.js")]
