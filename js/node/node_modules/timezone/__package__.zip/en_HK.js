module.exports = {
  "name": "en_HK",
  "day": {
    "abbrev": [
      "Sun",
      "Mon",
      "Tue",
      "Wed",
      "Thu",
      "Fri",
      "Sat"
    ],
    "full": [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ]
  },
  "month": {
    "abbrev": [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ],
    "full": [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ]
  },
  "meridiem": [
    "AM",
    "PM"
  ],
  "date": "%A, %B %d, %Y",
  "time24": "%I:%M:%S %Z",
  "dateTime": "%A, %B %d, %Y %p%I:%M:%S %Z",
  "time12": "%p%I:%M:%S %Z"
}
