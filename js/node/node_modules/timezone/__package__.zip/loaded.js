module.exports = require("timezone")(require("timezone/zones"), require("timezone/locales"));
