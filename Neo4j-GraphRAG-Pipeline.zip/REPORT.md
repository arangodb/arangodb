# Detailed Project Report

## ArangoDB, GraphRAG, VectorRAG, and AI Retrieval Systems Evaluation

## 1. Executive Summary

This project documented hands-on learning, testing, debugging, and evaluation of AI retrieval systems built around ArangoDB, GraphRAG, VectorRAG, graph databases, vector search, AQL, notebook servers, and Kubernetes-based development environments.

The work combined foundational study with applied technical investigation. Core activities included learning graph database concepts, practicing AQL, comparing GraphRAG implementations, testing retriever behavior, identifying backend reliability issues, debugging notebook deployment problems, and creating reusable evaluation materials.

The project emphasized not only how retrieval systems work, but why each layer matters:

- Graph databases represent relationships directly.
- AQL supports structured and deterministic retrieval.
- Vector search enables semantic similarity.
- Indexes and search views affect relevance and performance.
- Authentication and error handling determine production reliability.
- Evaluation questions make retriever comparison repeatable.

## 2. Project Goals

The project goals were:

1. Build practical familiarity with ArangoDB, graph databases, and AQL.
2. Understand how GraphRAG extends traditional RAG with graph structure.
3. Compare retrieval methods across vector, graph, and structured query approaches.
4. Investigate VectorRAG reliability issues during database operations.
5. Analyze backend error-handling behavior when services return error payloads.
6. Debug notebook server deployment issues involving UI state and Kubernetes pod state.
7. Research multiple GraphRAG implementations and competitor systems.
8. Create evaluation questions to compare retrieval accuracy and consistency.
9. Produce documentation that communicates findings, skills, and lessons learned.

## 3. Project Scope

| Area | Description |
|---|---|
| ArangoDB fundamentals | Databases, collections, documents, graphs, indexes, and search views |
| AQL | Structured querying, graph traversal, filtering, and retrieval templates |
| Vector retrieval | Embeddings, semantic search, vector indexes, and VectorRAG behavior |
| GraphRAG | Graph-based retrieval, entity relationships, communities, and comparison research |
| Backend reliability | Auth token refresh, database handle rebinding, structured errors |
| Deployment debugging | Notebook server status, Kubernetes pending pods, K9s inspection, 503 failures |
| Evaluation design | Reusable question set and retriever comparison categories |
| Documentation | Notes, reports, onboarding material, shared resources, resume-ready summaries |

## 4. Quantitative Data

The available chat data contained several measurable details.

| Metric | Quantity / Detail |
|---|---:|
| Evaluation questions created | 10 |
| Retriever types compared in one mini-project | 3 |
| Main GraphRAG systems assigned for study | 3 |
| Additional competitor systems mentioned | 3+ |
| VectorRAG query types discussed | 4 |
| Query type associated with observed issue | 4 |
| HTTP/service errors observed | 404 and 503 |
| Backend exception identified | `KeyError: 'result'` |
| US interns referenced in onboarding | 4 |
| Spanish interns added to team channel | 5 |
| Main GraphRAG implementation assignments | Nano, Neo4j, Microsoft |
| Main deployment components discussed | Notebook server, retriever, importer, reasoner, MCP server |
| Example reasoner version referenced | `v0.0.1-2627c9a` |
| Example MCP server version referenced | `v0.0.1-318abf4` |
| Example GraphRAG retriever version referenced | `v0.0.13` |
| Shared analysis artifacts mentioned | Reports, spreadsheets, Google Docs, Drive folders, setup docs |

### Metrics Not Yet Measured

The chat did not include measured accuracy, latency, precision, recall, or benchmark scores. Future work should add:

- Accuracy by question
- Precision@k
- Recall@k
- Mean reciprocal rank
- Response latency
- Query success rate
- Token refresh failure rate
- Error rate by retriever
- Notebook startup time
- 404/503 frequency

## 5. Technical Fundamentals

### 5.1 Graph Databases

Graph databases model data as nodes and relationships. This project focused on graph concepts such as:

- Nodes
- Edges
- Collections
- Documents
- Graph traversal
- Relationship-based querying
- Multi-hop reasoning

### Why Graph Fundamentals Matter

Many AI retrieval problems are not just about finding a similar document. They involve connected information, such as:

- Which entities are related?
- What path connects two items?
- Which records share a common attribute?
- Which relationships explain a recommendation or answer?

Graph structure helps answer these questions more naturally than repeated SQL joins or simple keyword search.

### 5.2 AQL

AQL, the ArangoDB Query Language, was studied as the structured query layer for ArangoDB.

Project learning included:

- Basic AQL syntax
- Collection queries
- Document filtering
- Graph traversal patterns
- Search-related queries
- AQL template retrieval

### Why AQL Matters

AQL is important because it provides precision. Vector retrieval can find semantically similar text, but AQL can answer structured questions, apply exact filters, traverse known relationships, and perform deterministic retrieval.

### 5.3 Vector Search

Vector search was studied in the context of VectorRAG and semantic retrieval.

The common workflow was:

1. Load content.
2. Chunk text into smaller passages.
3. Generate embeddings.
4. Store chunks and embeddings.
5. Create a vector index.
6. Run semantic similarity search.

### Why Vector Search Matters

Vector search helps answer questions even when the user's wording does not exactly match the source document. It is useful for semantic recall, open-ended questions, and exploratory retrieval.

### 5.4 GraphRAG

GraphRAG combines retrieval-augmented generation with graph structure. Instead of only retrieving text chunks, it can use:

- Entities
- Relationships
- Communities
- Graph traversal
- Structured context
- Summaries over connected data

GraphRAG systems researched included:

- Microsoft GraphRAG
- Neo4j GraphRAG
- Nano GraphRAG
- Elastic-related approaches
- PuppyGraph
- EDB Postgres AI

### Why GraphRAG Matters

GraphRAG can support richer context and stronger reasoning for questions that depend on relationships, entity networks, or multi-hop connections.

### 5.5 Indexes and Search Views

The project included discussion of inverted indexes and ArangoSearch Views.

| Concept | Role |
|---|---|
| Inverted index | Low-level search index for a collection |
| ArangoSearch View | Higher-level search abstraction that can combine multiple indexes and support ranking |
| Vector index | Enables similarity search over embeddings |

### Why Indexing Matters

Retrieval quality and speed depend heavily on indexing. Without the right index strategy, a retriever may be slow, inaccurate, or unable to rank results effectively.

## 6. Workstream 1: VectorRAG Testing

The project included testing VectorRAG behavior across query types.

### Issue 1: Token Refresh

During testing, a `404` occurred on the GraphRAG query endpoint. The issue appeared consistent with an expired or stale authentication token.

Other retrievers refreshed the token before database operations, but VectorRAG appeared not to follow the same pattern.

### Proposed Fix

The proposed fix was to:

1. Refresh the authentication token before database operations.
2. Rebind or update the database handle.
3. Execute the query after credentials are current.

### Why This Matters

If a retriever uses stale credentials, valid database operations can fail. Authentication reliability is essential for any AI service backed by a database.

## 7. Workstream 2: Backend Error Handling

Another issue involved backend assumptions about response shape.

### Issue

When authentication failed, the service returned an error payload rather than a normal successful response. The server then assumed that this field existed:

```python
response["result"]
```

When it did not exist, the server crashed with:

```text
KeyError: 'result'
```

### Proposed Fix

The service should:

1. Check whether the response includes an error.
2. Avoid assuming `result` exists.
3. Return a structured error response.
4. Log the original failure for debugging.
5. Preserve service stability instead of crashing.

### Why This Matters

AI services should fail predictably. A structured error helps frontend users, backend engineers, and support teams understand what went wrong.

## 8. Workstream 3: Notebook Server Debugging

A notebook server was created through the UI in a development stack. The UI showed the notebook as deployed, but Kubernetes/K9s showed the pod as pending.

When the notebook was accessed through the UI, the user saw:

```text
Failed to Load Notebook
503
```

### Interpretation

This suggested a mismatch between:

- UI deployment status
- Kubernetes pod readiness
- Actual service availability

### Why This Matters

Notebook environments are often used for AI experimentation, testing, and debugging. If the UI reports "deployed" but the pod is still pending, users may not know where the failure is occurring.

## 9. Workstream 4: GraphRAG Research

The project involved comparing several GraphRAG implementations and related competitor tools.

| System | Research Focus |
|---|---|
| Microsoft GraphRAG | Entity extraction, graph construction, community detection, global/local search |
| Neo4j GraphRAG | Knowledge graph retrieval, Neo4j integration, graph-native retrieval patterns |
| Nano GraphRAG | Lightweight GraphRAG architecture and implementation |
| Elastic | Search and AI retrieval competitor patterns |
| PuppyGraph | Graph query and analytics competitor |
| EDB Postgres AI | Postgres-based AI and retrieval approach |

### Assignment Breakdown

| GraphRAG Implementation | Assigned Focus |
|---|---|
| Nano GraphRAG | Pragati |
| Neo4j GraphRAG | Pooja and Shailah |
| Microsoft GraphRAG | Pranav |

## 10. Workstream 5: Retriever Comparison Project

A small comparison project tested three retriever approaches on a movie knowledge graph.

### Retriever Types

1. Basic vector retriever
2. Graph-enhanced retriever
3. AQL template retriever

### Findings

| Retriever | Strength | Limitation |
|---|---|---|
| Basic vector retriever | Good for semantic similarity | Struggles with aggregation |
| Graph-enhanced retriever | Good for relationship-aware questions | Can be affected by anchor exclusion issues |
| AQL template retriever | Good for structured, predictable questions | Weak for open-ended semantic recall |

### Main Learning

Each retriever failed on a different class of question. This suggests that production retrieval systems may benefit from hybrid retrieval, where vector search, graph traversal, and structured queries are combined.

## 11. Workstream 6: Evaluation Question Design

A reusable 10-question set was proposed to compare retrieval behavior.

| # | Question |
|---:|---|
| 1 | How should vaccines be kept cold in the cold chain? |
| 2 | What should I do to give a safe injection? |
| 3 | How do I plan an immunization session? |
| 4 | How do you dispose of used needles and syringes safely? |
| 5 | What is herd immunity? |
| 6 | How do I talk to parents who refuse vaccination? |
| 7 | What records should be kept after vaccinating a child? |
| 8 | How can I stop medicines from going bad during a power cut? |
| 9 | A child got a fever after a vaccination shot, what should I do? |
| 10 | How far in advance should supplies be ordered? |

### Evaluation Value

These questions test:

- Factual recall
- Procedural retrieval
- Safety guidance
- Planning support
- Conceptual explanation
- Multi-step answer construction
- Consistency across retrievers

## 12. Project Methodology

### Phase 1: Product and Platform Onboarding

Studied introductory resources about Arango AI, ArangoDB, Agentic AI Suite, and the Contextual Data Platform.

### Phase 2: Graph Database Fundamentals

Learned graph database concepts, including documents, collections, nodes, edges, graphs, and traversal patterns.

### Phase 3: Local ArangoDB Setup

Installed ArangoDB locally using Docker and practiced creating databases, collections, and graphs.

### Phase 4: AQL Practice

Worked through AQL fundamentals and graph traversal syntax to understand structured retrieval.

### Phase 5: Notebook and Python Driver Practice

Used notebook workflows and ArangoDB Python driver tutorials to connect database operations with Python-based AI development.

### Phase 6: GraphRAG Research

Reviewed GraphRAG implementations, papers, competitor repositories, and research materials.

### Phase 7: Retriever Testing

Tested VectorRAG and GraphRAG query behavior, including multiple query types.

### Phase 8: Reliability Investigation

Investigated token refresh and backend error-handling issues.

### Phase 9: Deployment Debugging

Compared UI deployment state with Kubernetes pod state for notebook server failures.

### Phase 10: Documentation and Sharing

Created and shared learning resources, evaluation questions, comparison spreadsheets, and technical notes.

## 13. Skills Demonstrated

### Technical Skills

- ArangoDB
- AQL
- Graph databases
- Graph traversal
- GraphRAG
- VectorRAG
- Retrieval-augmented generation
- Vector search
- Semantic search
- Embeddings
- Sentence Transformers
- Inverted indexes
- ArangoSearch Views
- Vector indexes
- Python notebooks
- Docker
- Kubernetes
- K9s
- API debugging
- Backend error handling
- Authentication debugging

### Research Skills

- GraphRAG architecture review
- Competitive analysis
- Technical comparison
- Retrieval evaluation design
- Research paper review
- Failure-mode analysis
- Question-set creation

### Engineering Skills

- Service debugging
- HTTP error analysis
- Kubernetes status investigation
- Backend reliability thinking
- Structured error response design
- Token lifecycle analysis
- Database operation debugging

### Collaboration Skills

- Technical documentation
- Team onboarding support
- Knowledge sharing
- Asking targeted technical questions
- Coordinating access requirements
- Sharing research findings
- Supporting group learning

## 14. Deliverables

The project produced or contributed to:

1. AQL syntax notes.
2. ArangoDB setup guidance.
3. GraphRAG comparison materials.
4. Retriever comparison report.
5. 10-question retrieval evaluation set.
6. VectorRAG token-refresh investigation.
7. Backend error-handling recommendations.
8. Notebook server debugging observations.
9. Shared GraphRAG research links and papers.
10. Resume and LinkedIn-ready project summaries.

## 15. Key Lessons Learned

1. Graph structure is valuable when retrieval depends on relationships.
2. Vector search is useful for semantic similarity but not always enough.
3. AQL provides precision for structured and deterministic queries.
4. Hybrid retrieval can reduce the weaknesses of individual retriever types.
5. Authentication should be refreshed before database operations.
6. Backend services should handle error responses explicitly.
7. UI deployment status should match infrastructure readiness.
8. Evaluation questions are essential for comparing retrieval systems.
9. Indexing choices directly affect retrieval quality and performance.
10. Technical documentation improves team learning and project continuity.

## 16. Recommended Future Work

Future improvements could include:

- Build a Streamlit demo for querying graph, vector, and document data.
- Add benchmark scoring for the 10 evaluation questions.
- Implement precision@k and recall@k scoring.
- Track latency for each retriever.
- Add automated tests for token refresh behavior.
- Add structured error-handling tests.
- Build a hybrid retriever combining vector search, graph traversal, and AQL.
- Add sample notebooks for ArangoDB and GraphRAG workflows.
- Visualize graph topology with Plotly.
- Compare ArangoDB results against Neo4j and Microsoft GraphRAG outputs.

## 17. Final Summary

This project demonstrated hands-on learning and applied engineering across ArangoDB, GraphRAG, VectorRAG, AQL, graph databases, vector search, Kubernetes debugging, and AI retrieval evaluation.

The project moved from fundamentals to applied debugging: learning how graphs and AQL work, studying GraphRAG systems, testing retriever behavior, finding auth and error-handling issues, debugging notebook deployments, and creating evaluation materials.

The strongest outcome was a deeper understanding of how graph, vector, and structured retrieval methods can work together to support more reliable AI applications.
