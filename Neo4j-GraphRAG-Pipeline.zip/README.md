# GraphRAG and VectorRAG Retrieval Systems Evaluation

Portfolio project documenting hands-on learning, testing, debugging, and evaluation of AI retrieval systems using ArangoDB, GraphRAG, VectorRAG, AQL, graph databases, vector search, notebooks, and Kubernetes-based development environments.

## Project Snapshot

**Project type:** Research, debugging, and technical evaluation  
**Focus:** GraphRAG, VectorRAG, ArangoDB, AQL, vector search, graph traversal, retriever reliability  
**Primary outcome:** A structured report of findings, fundamentals, failure modes, evaluation questions, and resume-ready project material.

## Why This Project Matters

Modern AI applications often need more than basic text search. Real-world questions may require:

- Semantic similarity across document chunks
- Relationship-aware graph traversal
- Structured queries over known entities
- Reliable authentication and database access
- Clear backend error handling
- Repeatable evaluation across retriever types

This project explores how graph, vector, and structured retrieval methods can complement each other when building reliable retrieval-augmented generation systems.

## Core Areas Covered

| Area | What was studied or tested | Why it matters |
|---|---|---|
| Graph databases | Nodes, edges, collections, traversals, connected data | Enables relationship-aware retrieval and multi-hop reasoning |
| AQL | Structured ArangoDB queries and graph traversals | Supports precise, deterministic retrieval |
| Vector search | Embeddings and semantic similarity | Helps retrieve meaningfully related content when keywords differ |
| GraphRAG | Microsoft GraphRAG, Neo4j GraphRAG, Nano GraphRAG | Shows how graphs can improve RAG context and reasoning |
| VectorRAG | Query behavior, auth issues, DB operations | Reveals reliability requirements for AI retrieval services |
| Indexing | Inverted indexes, ArangoSearch Views, vector indexes | Impacts retrieval speed, relevance, and scalability |
| Deployment debugging | Notebook servers, K9s, Kubernetes states, 503 errors | Connects UI behavior to infrastructure readiness |
| Evaluation | 10-question benchmark set and retriever comparison | Makes retrieval quality easier to compare |

## Quantitative Highlights

| Metric | Value |
|---|---:|
| Evaluation questions designed | 10 |
| Retriever types compared | 3 |
| Main GraphRAG systems researched | 3 |
| Additional competitor systems discussed | 3+ |
| VectorRAG query modes discussed | 4 |
| Query mode with observed issue | 4 |
| HTTP/service errors analyzed | 404, 503 |
| Backend exception identified | `KeyError: 'result'` |
| Main project workstreams | 6 |
| Main technical skill categories | 4 |

## Main Findings

1. **Vector retrieval is strong for semantic recall but weak for aggregation.**
2. **Graph-enhanced retrieval is useful for connected and multi-hop questions.**
3. **AQL-template retrieval is precise for structured questions but limited for open-ended semantic recall.**
4. **Authentication token refresh is critical for reliable retriever/database operations.**
5. **Backend services should handle error payloads explicitly instead of assuming successful response schemas.**
6. **Notebook UI deployment status must be validated against Kubernetes pod readiness.**
7. **Hybrid retrieval can combine vector search, graph traversal, and structured querying.**

## Repository Contents

```text
.
├── README.md
├── REPORT.md
├── RESUME.md
├── LINKEDIN_POST.md
├── data
│   ├── evaluation_questions.csv
│   └── project_metrics.json
└── docs
    ├── findings.md
    ├── methodology.md
    └── skills_matrix.md
```

## Resume Preview

**GraphRAG + VectorRAG Retrieval Systems Evaluation**  
Python · ArangoDB · AQL · GraphRAG · VectorRAG · Kubernetes · K9s · Docker · Vector Search

Evaluated graph-based, vector-based, and structured AQL retrieval workflows to understand how AI systems retrieve connected and semantic context. Tested VectorRAG query behavior, identified token-refresh and backend error-handling issues, debugged notebook deployment failures, and designed a 10-question evaluation set for comparing GraphRAG retriever quality across Microsoft GraphRAG, Neo4j GraphRAG, and Nano GraphRAG.

See [`RESUME.md`](RESUME.md) for full resume-ready project entries.

## Documentation

- [`REPORT.md`](REPORT.md): Full project report
- [`docs/methodology.md`](docs/methodology.md): Step-by-step project process
- [`docs/findings.md`](docs/findings.md): Technical findings and lessons learned
- [`docs/skills_matrix.md`](docs/skills_matrix.md): Skills demonstrated
- [`LINKEDIN_POST.md`](LINKEDIN_POST.md): LinkedIn-ready project post

## Suggested Future Improvements

- Add measured retrieval accuracy for each retriever type.
- Track latency and query success rate.
- Score answers using precision@k, recall@k, and mean reciprocal rank.
- Build a small interactive demo using Streamlit.
- Add sample notebooks for ArangoDB, AQL, GraphRAG, and vector search.
- Implement a hybrid retrieval prototype combining AQL, graph traversal, and vector search.
