# Methodology

This project followed a learning-to-application workflow. The goal was to start from fundamentals, apply them in practical testing, and document findings in a way that could be reused for future AI retrieval work.

## Phase 1: Product and Platform Onboarding

The project began by reviewing introductory materials about:

- Arango AI
- ArangoDB
- Agentic AI Suite
- Contextual Data Platform
- Graph databases
- Retrieval-augmented generation

## Phase 2: ArangoDB and Graph Fundamentals

The next step was learning how ArangoDB represents data.

Topics included:

- Databases
- Collections
- Documents
- Graphs
- Nodes
- Edges
- Traversals
- Connected data use cases

## Phase 3: Local Development Setup

ArangoDB was installed locally using Docker so database concepts could be practiced directly.

Local practice included:

- Starting ArangoDB
- Creating databases
- Creating collections
- Creating documents
- Creating graphs
- Testing simple queries

## Phase 4: AQL Practice

AQL was studied as the structured query language for ArangoDB.

Practice areas included:

- Basic query syntax
- Filtering
- Returning documents
- Graph traversal patterns
- Structured query templates
- Understanding when AQL is more suitable than vector search

## Phase 5: Notebook and Python Driver Practice

Notebook workflows were used to connect Python-based experimentation with ArangoDB.

This phase included:

- Creating notebooks
- Reviewing ArangoDB Python driver material
- Understanding how notebook environments support AI experiments
- Debugging notebook server deployment issues

## Phase 6: GraphRAG Research

GraphRAG systems and competitors were researched to understand different approaches.

Systems included:

- Microsoft GraphRAG
- Neo4j GraphRAG
- Nano GraphRAG
- Elastic
- PuppyGraph
- EDB Postgres AI

## Phase 7: Retriever Comparison

Three retrieval approaches were compared:

1. Basic vector retrieval
2. Graph-enhanced retrieval
3. AQL-template retrieval

The comparison focused on where each approach performed well and where each one failed.

## Phase 8: Reliability Investigation

VectorRAG and GraphRAG workflows were tested for reliability issues.

Key areas investigated:

- Token refresh behavior
- Database operation failures
- Query modes
- Error payload handling
- Backend crashes caused by missing response fields

## Phase 9: Evaluation Design

A reusable 10-question evaluation set was created to support consistent comparison across retrievers.

The questions covered:

- Factual recall
- Procedural guidance
- Safety guidance
- Planning
- Conceptual explanation
- Communication guidance

## Phase 10: Documentation

Findings were organized into:

- A full project report
- Resume-ready project entries
- LinkedIn post drafts
- Skills matrix
- Structured project metrics
- Evaluation question dataset
