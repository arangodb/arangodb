# Skills Matrix

## Technical Skills

| Skill | Evidence from project | Why it matters |
|---|---|---|
| ArangoDB | Studied databases, collections, documents, graphs, indexes, and search views | Core database platform for graph, document, and search workflows |
| AQL | Practiced structured queries and graph traversal syntax | Enables precise retrieval and deterministic answers |
| Graph databases | Learned nodes, edges, relationships, traversals, and connected data | Supports relationship-aware retrieval and multi-hop reasoning |
| GraphRAG | Compared Microsoft GraphRAG, Neo4j GraphRAG, and Nano GraphRAG | Adds graph structure to retrieval-augmented generation |
| VectorRAG | Tested query behavior and reliability issues | Supports semantic retrieval over embedded content |
| Vector search | Studied embeddings and similarity search | Enables meaning-based retrieval when exact keywords are insufficient |
| Inverted indexes | Compared low-level text-search indexing with search views | Helps understand text search performance and relevance |
| ArangoSearch Views | Studied higher-level search abstraction over indexes | Supports ranking and search across one or more collections |
| Kubernetes | Investigated notebook deployment state | Important for debugging cloud-hosted AI services |
| K9s | Used to compare pod state against UI status | Helps inspect Kubernetes resources quickly |
| Docker | Used for local ArangoDB setup | Supports reproducible local development |
| Backend error handling | Analyzed missing `result` crash scenario | Prevents service failures and improves reliability |
| Authentication debugging | Investigated stale-token behavior | Critical for database-backed API reliability |

## AI and Retrieval Skills

| Skill | Evidence from project |
|---|---|
| Retrieval evaluation | Created a 10-question evaluation set |
| Semantic search analysis | Compared vector retriever strengths and weaknesses |
| Graph retrieval analysis | Studied relationship-aware retrieval and graph traversal |
| Hybrid retrieval thinking | Identified why vector, graph, and AQL retrieval should be combined |
| Competitive research | Reviewed Microsoft GraphRAG, Neo4j GraphRAG, Nano GraphRAG, Elastic, PuppyGraph, and EDB Postgres AI |
| Failure-mode analysis | Identified retriever-specific weaknesses and backend crash scenarios |

## Engineering Skills

| Skill | Evidence from project |
|---|---|
| API debugging | Investigated 404 GraphRAG endpoint failure |
| Service reliability | Proposed token refresh and structured error handling |
| Deployment debugging | Investigated notebook 503 failure and pending pod state |
| Data modeling | Worked with graph, document, and vector retrieval concepts |
| Technical writing | Created reports, notes, project summaries, and resume content |

## Collaboration Skills

| Skill | Evidence from project |
|---|---|
| Documentation | Shared AQL notes, setup materials, and technical findings |
| Team onboarding | Supported new interns with resources and access coordination |
| Technical communication | Asked and answered questions about ArangoDB, GraphRAG, indexes, and retrieval |
| Research sharing | Shared papers, spreadsheets, and implementation comparisons |
| Cross-functional support | Helped coordinate demo, deployment, and access-related discussions |
