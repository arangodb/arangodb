# Technical Findings

## 1. Retriever Types Have Different Strengths

Three retriever types were compared:

| Retriever | Strength | Limitation |
|---|---|---|
| Basic vector retriever | Semantic similarity | Weak for aggregation and precise structured answers |
| Graph-enhanced retriever | Relationship-aware context | Depends on graph structure and anchoring decisions |
| AQL-template retriever | Structured precision | Weak for open-ended semantic recall |

## Main Lesson

No single retriever is ideal for every question. A production-quality retrieval system often benefits from combining vector search, graph traversal, and structured querying.

## 2. Vector Search Is Useful but Not Sufficient

Vector search is effective when the user's question is semantically similar to stored content, even if the wording differs.

However, vector search may struggle with:

- Counting
- Aggregation
- Exact filtering
- Multi-hop relationships
- Questions requiring deterministic answers

## 3. Graph Retrieval Adds Relationship Context

Graph-based retrieval helps when answers depend on connected information.

Examples of graph-friendly questions include:

- What entities are connected?
- Which records share a common relationship?
- What path connects two items?
- Which communities or clusters exist in the data?

## 4. AQL Is Valuable for Structured Retrieval

AQL is useful when the question can be translated into a structured query.

AQL works well for:

- Exact filters
- Known fields
- Graph traversals
- Structured records
- Aggregation
- Deterministic query results

## 5. Token Refresh Is Critical for Reliable Retrieval

VectorRAG testing surfaced a reliability concern where stale or expired authentication appeared to cause query failures.

Recommended improvement:

1. Refresh the token before database operations.
2. Rebind or update the database handle.
3. Run the query after credentials are current.

## 6. Structured Error Handling Prevents Backend Crashes

The backend expected responses to include:

```python
response["result"]
```

When an authentication failure returned an error payload instead, the server crashed with:

```text
KeyError: 'result'
```

Recommended improvement:

- Check for error payloads.
- Validate response shape.
- Return structured errors.
- Log the original failure.
- Avoid crashing the service.

## 7. UI Deployment Status Should Match Infrastructure State

A notebook server appeared deployed in the UI, but Kubernetes showed the pod as pending. Accessing the notebook returned a 503.

Main lesson:

Application UI status should be verified against underlying infrastructure readiness, especially for notebook servers and developer environments.

## 8. Evaluation Questions Make Comparison Repeatable

A reusable 10-question evaluation set was created to compare retrieval systems consistently.

The question set helps test:

- Factual recall
- Procedural retrieval
- Safety guidance
- Planning
- Conceptual explanation
- Communication-related responses

## 9. Indexing Choices Affect Retrieval Quality

The project included discussion of:

- Inverted indexes
- ArangoSearch Views
- Vector indexes

Indexing affects:

- Search speed
- Ranking quality
- Semantic retrieval
- Filtering
- Scalability

## 10. Hybrid Retrieval Is the Most Promising Direction

The most important project insight is that graph retrieval, vector retrieval, and structured querying are complementary.

A strong hybrid system could use:

1. Vector search for semantic candidate retrieval.
2. Graph traversal for relationship expansion.
3. AQL for structured filtering and aggregation.
4. Ranking to order the final result set.
5. Structured error handling for reliability.
