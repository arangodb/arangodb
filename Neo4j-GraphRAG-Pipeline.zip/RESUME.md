# Resume Project Entry

## Primary Resume Version

**GraphRAG Retrieval Lab: ArangoDB + VectorRAG** &nbsp;&nbsp; **Summer 2026**  
**Python · ArangoDB · AQL · GraphRAG · VectorRAG · Kubernetes · K9s · Docker · Vector Search · RAG**

Built to understand how graph traversal, semantic vector search, and structured database queries can work together inside AI retrieval systems. Enterprise AI teams face this exact challenge when answers depend on both meaning and relationships: vector search can retrieve similar text, graph traversal can surface connected context, and AQL can provide precise structured answers.

- Evaluated GraphRAG and VectorRAG workflows using ArangoDB, AQL, vector search, graph traversal, and notebook-based development environments.
- Compared 3 retrieval approaches: basic vector retrieval, graph-enhanced retrieval, and AQL-template retrieval, identifying where each method succeeds and fails.
- Designed a 10-question evaluation set to test factual recall, procedural retrieval, safety guidance, planning questions, and consistency across retrievers.
- Researched Microsoft GraphRAG, Neo4j GraphRAG, Nano GraphRAG, Elastic, PuppyGraph, and EDB Postgres AI to compare graph-based AI retrieval architectures.
- Investigated VectorRAG reliability issues involving stale auth tokens, database operation failures, and query behavior across 4 query modes.
- Proposed backend improvements to refresh authentication tokens before database operations and return structured errors instead of crashing on missing `result` fields.
- Debugged notebook server deployment failures by comparing UI deployment status with Kubernetes/K9s pod state, identifying 503 access failures caused by pending infrastructure.
- Documented fundamentals of graph databases, AQL, vector indexes, inverted indexes, ArangoSearch Views, and GraphRAG evaluation methodology.

---

## Shorter Resume Version

**GraphRAG Retrieval Lab: ArangoDB + VectorRAG** &nbsp;&nbsp; **Summer 2026**  
**Python · ArangoDB · AQL · GraphRAG · VectorRAG · Kubernetes · Docker · Vector Search**

- Evaluated graph-based, vector-based, and AQL-template retrieval workflows to understand how AI systems retrieve semantic and relationship-aware context.
- Compared 3 retriever types and designed a 10-question benchmark covering factual, procedural, planning, and safety-related retrieval tasks.
- Researched Microsoft GraphRAG, Neo4j GraphRAG, Nano GraphRAG, and related competitor systems to compare GraphRAG architectures.
- Identified VectorRAG reliability issues involving stale auth tokens and backend crashes from missing `result` fields; proposed token-refresh and structured-error fixes.
- Debugged notebook server failures involving UI/Kubernetes status mismatch, pending pods, and 503 errors using K9s and deployment logs.

---

## Even More Technical Version

**GraphRAG + VectorRAG Systems Evaluation** &nbsp;&nbsp; **Summer 2026**  
**ArangoDB · AQL · Graph Traversal · Vector Search · GraphRAG · Kubernetes · Python**

- Analyzed multi-modal retrieval patterns combining document retrieval, graph traversal, and embedding similarity within ArangoDB-based AI workflows.
- Compared vector, graph-enhanced, and AQL-template retrievers, showing that vector search improves semantic recall, graph traversal improves relationship-aware context, and AQL improves structured precision.
- Created a 10-question retrieval evaluation set for comparing accuracy and consistency across GraphRAG systems.
- Investigated VectorRAG auth-token lifecycle failures and proposed refreshing credentials plus rebinding database handles before query execution.
- Analyzed backend error handling where failed auth responses caused `KeyError: 'result'`, recommending explicit response validation and structured error returns.
- Researched GraphRAG competitors including Microsoft GraphRAG, Neo4j GraphRAG, Nano GraphRAG, Elastic, PuppyGraph, and EDB Postgres AI.

---

## One-Line Resume Bullet

Evaluated ArangoDB-based GraphRAG and VectorRAG retrieval workflows, comparing 3 retriever types, designing a 10-question benchmark, and identifying auth, error-handling, and Kubernetes notebook deployment issues affecting AI service reliability.
